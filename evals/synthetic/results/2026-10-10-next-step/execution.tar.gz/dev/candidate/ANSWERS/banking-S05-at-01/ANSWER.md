# Case banking-S05-at-01: Block my card, unblock it tomorrow, and refund two purchases

**Decision: submit_request**  (final state `REQUESTED`)

## Summary

Sofia Lindqvist, verified on a call, said she had lost her debit card and asked for it to be blocked, for an automatic unblock tomorrow, and for refunds of two unrecognised purchases (£23.10 and £64.00). The desk registered a request to the card team about the card, and the case closed with that as the only action taken. The automatic unblock and the refunds were not set up or started, so they are left for a person to handle separately.

_Written by a model from the record below; the sections below are the record._

## What the system received

- Source role: Bank customer
- Bank: Harrow & Vale Bank plc (fictional)
- Created: 2025-11-05 09:00:00 UTC

The request:

> I’ve lost my debit card. Please block it now, unblock it automatically tomorrow if I find it, and refund the two purchases I don’t recognise — £23.10 and £64.00.

What happened up to now:

1. 2025-11-05T09:00:00Z · Verified call — Sofia Lindqvist → H&V service agent

> After H&V completed its identification checks, I reported that I’ve lost my debit card, probably on the bus home. I asked for it to be blocked right now. I also asked if it could unblock automatically tomorrow in case I find it in a coat pocket, and for a refund of two purchases I don’t recognise from last night: £23.10 and £64.00. No security details were recorded in the call note.

Attachments: none.

Case reference: id banking-S05-at-01, track banking, case S05, point 1, actor_next bank.

## Actions taken

- `register_request` (team: card, about: card), by rule `do-request`

## Decision and why

How the case moved:

- `READING` → `TRIAGED`: rule `triage`.
  - state = READING → true (state=READING)
- `TRIAGED` → `REQUEST_PENDING`: the agent asked for `submit_request`, rule `card-instruction` accepted it.
  - state = TRIAGED → true (state=TRIAGED)
  - next_system = card → true (next_system=card)
  - card_asked absent → true (card_asked=not known)
  - verified → true (verified=True)
  - request_type = instruction → true (request_type=instruction)
- `REQUEST_PENDING` → `REQUESTED`: rule `do-request`.
  - state = REQUEST_PENDING → true (state=REQUEST_PENDING)

Facts established:

- requester: **Sofia Lindqvist**
- role: **customer**
- channel: **verified_call**
- verified: **True**
- subject: **card**
- amount: **23.10**
- confirmation: **none**
- instructed_outside_portal: **False**
- request_type: **instruction**
- next_system: **card**
- private_account_disclosure: **False**
- credentials_requested: **False**
- joint_holder_change: **False**

Where they came from:

- event 1 (Sofia Lindqvist): After H&V completed its identification checks, I reported that I’ve lost my debit card, probably on the bus home. I asked for it to be blocked right now. I also asked if it could unblock automatically tomorrow in case I find it in a coat pocket, and for a refund of two purchases I don’t recognise from last night: £23.10 and £64.00. No security details were recorded in the call note. [facts: requester='Sofia Lindqvist', role='customer', channel='verified_call', verified=True]
- event 1 (Sofia Lindqvist): After H&V completed its identification checks, I reported that I’ve lost my debit card, probably on the bus home. I asked for it to be blocked right now. I also asked if it could unblock automatically tomorrow in case I find it in a coat pocket, and for a refund of two purchases I don’t recognise from last night: £23.10 and £64.00. No security details were recorded in the call note. [facts: amount='23.10']
- event 1 (Sofia Lindqvist): After H&V completed its identification checks, I reported that I’ve lost my debit card, probably on the bus home. I asked for it to be blocked right now. I also asked if it could unblock automatically tomorrow in case I find it in a coat pocket, and for a refund of two purchases I don’t recognise from last night: £23.10 and £64.00. No security details were recorded in the call note. [facts: confirmation='none', instructed_outside_portal=False]

## Escalated

No.

## What failed

- nothing

## Final result

submit_request (REQUESTED)
