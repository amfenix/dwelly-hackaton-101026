# Case banking-S12-at-02: Goods never arrived — card dispute

**Decision: submit_request**  (final state `REQUESTED`)

## Summary

Callum Fairweather asked over secure chat to dispute a £189.00 card payment to Brindle & Oak Home, saying the side table he ordered never arrived. The desk could not verify him, but it classed the message as a request to register and passed it to the card team, where the case closed as requested. The dispute itself has not been decided, and what happens next is for the card team to review.

_Written by a model from the record below; the sections below are the record._

## What the system received

- Source role: Bank customer
- Bank: Harrow & Vale Bank plc (fictional)
- Created: 2025-11-12 09:00:00 UTC

The request:

> I paid £189.00 by card to Brindle & Oak Home, an online shop, about five weeks ago. Nothing has arrived and they don’t answer my emails. Can you dispute the payment?

What happened up to now:

1. 2025-11-12T09:00:00Z · Secure portal — H&V secure portal → Callum Fairweather

> Card transaction: Brindle & Oak Home — £189.00, posted 8 October 2025, debit card ending 2290.

2. 2025-11-12T09:47:00Z · Secure chat — Callum Fairweather → H&V service agent

> I ordered a side table from Brindle & Oak Home on their website and paid £189.00 by card on 8 October. It was supposed to arrive within ten days. Nothing has come, the tracking link never worked, and they haven’t replied to three emails. I’d like to dispute this payment, please.

Attachments: none.

Case reference: id banking-S12-at-02, track banking, case S12, point 2, actor_next bank.

## Actions taken

- `register_request` (team: card, about: card_payment), by rule `do-request`

## Decision and why

How the case moved:

- `READING` → `TRIAGED`: rule `triage`.
  - state = READING → true (state=READING)
- `TRIAGED` → `REQUEST_PENDING`: the agent asked for `submit_request`, rule `register` accepted it.
  - state = TRIAGED → true (state=TRIAGED)
  - request_type = register → true (request_type=register)
  - registration_asked absent → true (registration_asked=not known)
- `REQUEST_PENDING` → `REQUESTED`: rule `do-request`.
  - state = REQUEST_PENDING → true (state=REQUEST_PENDING)

Facts established:

- requester: **Callum Fairweather**
- role: **customer**
- channel: **secure_chat**
- verified: **False**
- subject: **card_payment**
- amount: **189.00**
- counterparty: **Brindle & Oak Home**
- confirmation: **none**
- instructed_outside_portal: **False**
- request_type: **register**
- next_system: **card**
- private_account_disclosure: **False**
- credentials_requested: **False**
- joint_holder_change: **False**

Where they came from:

- event 2 (Callum Fairweather): I ordered a side table from Brindle & Oak Home on their website and paid £189.00 by card on 8 October. It was supposed to arrive within ten days. Nothing has come, the tracking link never worked, and they haven’t replied to three emails. I’d like to dispute this payment, please. [facts: requester='Callum Fairweather', role='customer', channel='secure_chat', verified=False]
- event 2 (Callum Fairweather): I ordered a side table from Brindle & Oak Home on their website and paid £189.00 by card on 8 October. It was supposed to arrive within ten days. Nothing has come, the tracking link never worked, and they haven’t replied to three emails. I’d like to dispute this payment, please. [facts: amount='189.00', counterparty='Brindle & Oak Home']
- event 2 (Callum Fairweather): I ordered a side table from Brindle & Oak Home on their website and paid £189.00 by card on 8 October. It was supposed to arrive within ten days. Nothing has come, the tracking link never worked, and they haven’t replied to three emails. I’d like to dispute this payment, please. [facts: confirmation='none', instructed_outside_portal=False]

## Escalated

No.

## What failed

- nothing

## Final result

submit_request (REQUESTED)
