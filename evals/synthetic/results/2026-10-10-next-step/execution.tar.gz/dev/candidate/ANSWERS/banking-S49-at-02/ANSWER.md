# Case banking-S49-at-02: Three requests in one message

**Decision: ask_system**  (final state `ASKED`)

## Summary

Declan Ashworth, writing over secure chat and not yet verified, asked three things: when his standing order to his sister Saoirse next goes out, why he was charged £4.50 on 1 December, and for his address to be changed. The desk classed it as a question about a standing order and sent a query to the recurring payments system, which returned nothing in the record, so no answer has gone back to him. The £4.50 charge and the address change were not acted on, and the address change would need his identity verified first.

_Written by a model from the record below; the sections below are the record._

## What the system received

- Source role: Bank customer
- Bank: Harrow & Vale Bank plc (fictional)
- Created: 2025-12-19 09:00:00 UTC

The request:

> Three things: when does my standing order to my sister next go out, why was I charged £4.50 on 1 December, and please change my address to 14 Quillan Road — I’ve moved.

What happened up to now:

1. 2025-12-19T09:00:00Z · Secure portal — H&V system → Declan Ashworth

> Account activity: 1 December 2025 — charge £4.50.

2. 2025-12-19T09:47:00Z · Secure chat — Declan Ashworth → H&V service agent

> Three things please: when does my standing order to my sister Saoirse next go out, why was I charged £4.50 on 1 December, and can you change my address to 14 Quillan Road, Hebden Moor? I’ve just moved.

Attachments: none.

Case reference: id banking-S49-at-02, track banking, case S49, point 2, actor_next bank.

## Actions taken

- `ask_system` (system: recurring, about: standing_order, amount: 4.50), by rule `do-ask`

## Decision and why

How the case moved:

- `READING` → `TRIAGED`: rule `triage`.
  - state = READING → true (state=READING)
- `TRIAGED` → `ASK_PENDING`: the agent asked for `ask_system`, rule `recurring-ask` accepted it.
  - state = TRIAGED → true (state=TRIAGED)
  - args.system = recurring → true (args.system=recurring)
  - next_system = recurring → true (next_system=recurring)
  - next_system absent → false (next_system=recurring)
  - recurring_asked absent → true (recurring_asked=not known)
  - request_type not in [register, change, authority] → true (request_type=question)
- `ASK_PENDING` → `ASKED`: rule `do-ask`.
  - state = ASK_PENDING → true (state=ASK_PENDING)

Facts established:

- requester: **Declan Ashworth**
- role: **customer**
- channel: **secure_chat**
- verified: **False**
- subject: **standing_order**
- amount: **4.50**
- confirmation: **none**
- instructed_outside_portal: **True**
- request_type: **question**
- next_system: **recurring**
- private_account_disclosure: **False**
- credentials_requested: **False**
- joint_holder_change: **False**

Where they came from:

- event 2 (Declan Ashworth): Three things please: when does my standing order to my sister Saoirse next go out, why was I charged £4.50 on 1 December, and can you change my address to 14 Quillan Road, Hebden Moor? I’ve just moved. [facts: requester='Declan Ashworth', role='customer', channel='secure_chat', verified=False]
- event 2 (Declan Ashworth): Three things please: when does my standing order to my sister Saoirse next go out, why was I charged £4.50 on 1 December, and can you change my address to 14 Quillan Road, Hebden Moor? I’ve just moved. [facts: amount='4.50']
- event 2 (Declan Ashworth): Three things please: when does my standing order to my sister Saoirse next go out, why was I charged £4.50 on 1 December, and can you change my address to 14 Quillan Road, Hebden Moor? I’ve just moved. [facts: confirmation='none', instructed_outside_portal=True]

## Escalated

No.

## What failed

- nothing

## Final result

ask_system (ASKED)
